package com.axa.softwareacademy.p9.sprint1.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import java.util.Date;

import static javax.persistence.TemporalType.DATE;

@Entity
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"}, allowGetters = true)
@Table(name = "patients")
@Getter @Setter @NoArgsConstructor @ToString @AllArgsConstructor
public class Patient {
    @Id
    @NotNull
    @Column(unique = true, columnDefinition = "TINYINT")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @NotNull
    private String familyName;
    @NotNull
    private String givenName;
    @NotNull
    private String address;
    @Temporal(DATE)
    @DateTimeFormat(pattern="YYYY-MM-dd")
    private Date dob;
    @NotNull
    private String sex;
    private String phone;

}
