package com.axa.softwareacademy.p9.sprint1.repository;

import com.axa.softwareacademy.p9.sprint1.model.Patient;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface PatientRepository extends JpaRepository <Patient, Integer> {
    Patient findPatientByGivenName(String givenName);
}
