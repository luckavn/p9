package com.axa.softwareacademy.p9.sprint1;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing
@SpringBootApplication
public class FymrApplication {
	private static final Logger logger = LogManager.getLogger(FymrApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(FymrApplication.class, args);
		logger.debug("Application started");
	}

}
