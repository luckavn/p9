package com.axa.softwareacademy.p9.sprint1.rest;

import com.axa.softwareacademy.p9.sprint1.model.Patient;
import com.axa.softwareacademy.p9.sprint1.repository.PatientRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@Controller
public class PatientController {
    private static final Logger logger = LogManager.getLogger(PatientController.class);

    @Autowired
    PatientRepository patientRepository;

    /**
     * This endpoint allows to show patient
     * @return the patient
     */
    @RequestMapping(path = "/patients")
    public Patient patient(@RequestParam Integer id) throws Exception {
        Optional<Patient> result = patientRepository.findById(id);
        if(!result.isPresent()) {
            logger.debug("Find user by id failed");
            throw new Exception("4O4");
        }

        Patient patient = result.get();
        logger.debug(patient);
        return patient;
    }

    /**
     * This endpoint allows to show patient list to users
     * @return the patient list
     */
    @GetMapping("/patients/all")
    public List<Patient> patientList (){
        logger.debug("Start finding all patients");
        return patientRepository.findAll();
    }

    /**
     *
     * @param patient is a valid patient body
     * @return saved patient
     */
    @PostMapping
    public Patient addPatient (@RequestBody @Valid Patient patient) {
        logger.debug("Start saving patient");
        return patientRepository.save(patient);
    }

    /**
     * This endpoint allows to display patient updating form
     * @param id is the patient's id that is concerned by update
     */
    @PutMapping
    public Patient modifiedPatient(@RequestBody @Valid Patient patient, @RequestParam Integer id) throws Exception {

       Optional<Patient> result = patientRepository.findById(id);
       if(!result.isPresent()) {
           logger.debug("Find user by id failed");
           throw new Exception("404");
       }
       patient.setId(id);
       return patientRepository.save(patient);
    }

    /**
     * This endpoint deletes a saved patient object
     * @param id is the patient id that is concerned by deleting
     */
    @DeleteMapping
    public void deletePatient(@RequestParam Integer id) throws Exception {
        Optional<Patient> result = patientRepository.findById(id);
        if(!result.isPresent()) {
            logger.debug("Find user by id failed");
            throw new Exception("404");
        }
       patientRepository.delete(result.get());
    }
}


