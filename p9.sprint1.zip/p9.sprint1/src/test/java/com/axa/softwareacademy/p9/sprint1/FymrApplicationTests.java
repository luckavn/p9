package com.axa.softwareacademy.p9.sprint1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FymrApplicationTests {

	@Test
	void contextLoads() {
	}

}
