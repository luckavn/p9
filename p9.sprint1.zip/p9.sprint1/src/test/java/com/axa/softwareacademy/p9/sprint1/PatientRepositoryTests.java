package com.axa.softwareacademy.p9.sprint1;

import com.axa.softwareacademy.p9.sprint1.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PatientRepositoryTests {

    @Autowired
    PatientRepository patientRepository;

   /* @Test
    public void testSavePatient() {
        Patient patient = new Patient(1,"TestNone","Test","1 Brookside St", new Date(1966-12-31),"F","100-222-3333");
        System.out.println(patient);
        patientRepository.save(patient);
        Patient patient2 = patientRepository.findPatientByGivenName("Test");
        assertNotNull(patient);
        assertEquals(patient2.getGivenName(), patient.getGivenName());
        assertEquals(patient2.getFamilyName(), patient.getGivenName());
    }

    @Test
    public void testGetPatient() {

    }

    @Test
    public void testDeletePatient() {

    }

    @Test
    public void testFindAllPatients() {

    }*/

}
